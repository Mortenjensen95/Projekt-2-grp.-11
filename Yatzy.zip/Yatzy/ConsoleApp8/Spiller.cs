﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yahtzee
{
    public class Spiller
    {
        public string navn = "";

        public int[] Scoring = new int[15];                          // et array til at holde scores fra scoreboard
        public bool[] TjekOmBrugtFoer = new bool[15];

        public int UdregnTotal()
        {
            int totalScore = 0;
            //totalScore = 0;
            for (int i = 0; i < 14; i++)
            {
                totalScore += Scoring[i];
            }
            return totalScore;
        }

        // totalScore = UdregnTotal();

    }
}
