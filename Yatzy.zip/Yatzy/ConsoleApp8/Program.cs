﻿using System.ComponentModel.Design;
using System.Globalization;
using System.Numerics;
using System.Security.Cryptography.X509Certificates;
using Yahtzee;
using static System.Formats.Asn1.AsnWriter;
using System.Collections.Generic;


internal class Program
{
    private static void Main(string[] args)
    {
        int antalSpillere;
        int nuværendeSpiller = 0;                                                                       // 0, fordi vi altid starter med spiller 1
        int[] terninger = new int[5];                                                                   // erklærer et int array med fem værdier til de fem terningers værdier
        int terningeKast = 2;                                                                           // 2, fordi det første rul, der sker automatisk, tæller som første/det 3. kast
        int terningeNummer = 0;                                                                         // til at printe nummeret på terninger (f.eks. "terning #1, terning #2 osv..." --- ikke terningens værdi)
        int score = 0;
        bool kastIgen = true;                                                                           // om spilleren vil kaste igen eller gå til scoring
        string choice;
        int count = 1;
        List<int> terningerDerKastesIgen = new List<int>();                                             // en liste til at holde numrene på terningerne, der skal rulles igen (liste pga. dynamic sizing)
        List<Spiller> spillere = new List<Spiller>();                                                   // en liste med de forskellige spiller-objekter
        Random r = new Random();
        int[] sums = new int[6];                                                                        // et array med summerne af de forskellige antal øjne på terningerne
        string vinder = "";
        int maksScore = 0;

        Console.WriteLine("Velkommen til YATZY! \nHvor mange spillere er I? (2-4)");
        antalSpillere = int.Parse(Console.ReadLine());                                                  // skal være mindst 2?


        for (int i = 0; i < antalSpillere; i++)
        {
            Console.Write($"Indtast navnet på spiller {i + 1}: ");
            string spillerNavn = Console.ReadLine();

            Spiller spiller = new Spiller { navn = spillerNavn };
            spillere.Add(spiller);                                                                      // LISTEN 'spillere' er til Spiller objekter, så der tilføjes en Spiller class til listen hvert loop med en værdi til navnefeltet
        }


        void rulTerninger()
        {
            for (int i = 0; i < 5; i++)                                                                 // skriver fem random values ind i arrayet 'terninger' på index 1-5 (et for hver terning)
            {
                int randomVal = r.Next(1, 7);                                                           // (1,7) fordi sidste index ikke er inkluderet
                terninger[i] = randomVal;
            }
        }

        void printTerninger()                                                                           // METODE: print 'terninger' arrayet -- viser terningernes værdier til spilleren
        {
            Console.WriteLine("\nDu har rullet: \n");

            foreach (int i in terninger)
            {
                terningeNummer++;                                                                       // terningeNummer stiger 1 i værdi hvert loop (1-5) for hver terning
                Console.Write("Terning {0}: {1}", terningeNummer, i + "\n");
            }
            terningeNummer = 0;                                                                         // resetter terningeNumre så de ikke akkumulerer (f.eks. "terning 6, terning 7...")
        }

        void visScoreboard()                                                                            // metode til at vise Scoreboardet
        {
            Console.WriteLine("{0}s scoreboard", spillere[nuværendeSpiller].navn);

            Console.WriteLine("A. 1'ere..................* {0} *", spillere[nuværendeSpiller].Scoring[0]);
            Console.WriteLine("B. 2'ere..................* {0} *", spillere[nuværendeSpiller].Scoring[1]);
            Console.WriteLine("C. 3'ere..................* {0} *", spillere[nuværendeSpiller].Scoring[2]);
            Console.WriteLine("D. 4'ere..................* {0} *", spillere[nuværendeSpiller].Scoring[3]);
            Console.WriteLine("E. 5'ere..................* {0} *", spillere[nuværendeSpiller].Scoring[4]);
            Console.WriteLine("F. 6'ere..................* {0} *", spillere[nuværendeSpiller].Scoring[5]);
            Console.WriteLine("G. Et par.................* {0} *", spillere[nuværendeSpiller].Scoring[6]);
            Console.WriteLine("H. To par.................* {0} *", spillere[nuværendeSpiller].Scoring[7]);
            Console.WriteLine("I. Tre ens................* {0} *", spillere[nuværendeSpiller].Scoring[8]);
            Console.WriteLine("J. Fire ens...............* {0} *", spillere[nuværendeSpiller].Scoring[9]);
            Console.WriteLine("K. Lille straight.........* {0} *", spillere[nuværendeSpiller].Scoring[10]);
            Console.WriteLine("L. Store straight.........* {0} *", spillere[nuværendeSpiller].Scoring[11]);
            Console.WriteLine("M. Fuldt hus..............* {0} *", spillere[nuværendeSpiller].Scoring[12]);
            Console.WriteLine("N. Yatzy..................* {0} *", spillere[nuværendeSpiller].Scoring[13]);
            Console.WriteLine("O. Chancen................* {0} *", spillere[nuværendeSpiller].Scoring[14]);
            Console.WriteLine("TOTAL.....................* {0} *", spillere[nuværendeSpiller].UdregnTotal());
        }

        static int SumOfNumberOfEyes(int eyes, int t1, int t2, int t3, int t4, int t5)                  // ved første funktionskald, sum1(), tjekkes der om eyes er lig 1 for hver terning (t1-t5) --- r bliver et udtryk for hvor mange terninger, der var med 'eyes'-værdien
        {
            int r = 0;
            if (eyes == t1) r++;
            if (eyes == t2) r++;
            if (eyes == t3) r++;
            if (eyes == t4) r++;
            if (eyes == t5) r++;
            return r;
        }

        void vælgScoring()                                                                              // metode til at vælge en terningekombination
        {
            sums[0] = SumOfNumberOfEyes(1, terninger[0], terninger[1], terninger[2], terninger[3], terninger[4]);
            sums[1] = SumOfNumberOfEyes(2, terninger[0], terninger[1], terninger[2], terninger[3], terninger[4]);
            sums[2] = SumOfNumberOfEyes(3, terninger[0], terninger[1], terninger[2], terninger[3], terninger[4]);
            sums[3] = SumOfNumberOfEyes(4, terninger[0], terninger[1], terninger[2], terninger[3], terninger[4]);
            sums[4] = SumOfNumberOfEyes(5, terninger[0], terninger[1], terninger[2], terninger[3], terninger[4]);
            sums[5] = SumOfNumberOfEyes(6, terninger[0], terninger[1], terninger[2], terninger[3], terninger[4]);

            visScoreboard();

            Console.WriteLine("\nVælg en af følgende muligheder for at få points eller et andet bogstav på scoreboardet for at stryge den kombination:\n");

            try
            {
                if (sums[0] >= 1)
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[0])
                        Console.WriteLine("A. 1'ere");
                }
                if (sums[1] >= 1)
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[1])
                        Console.WriteLine("B. 2'ere");
                }
                if (sums[2] >= 1)
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[2])
                        Console.WriteLine("C. 3'ere");
                }
                if (sums[3] >= 1)
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[3])
                        Console.WriteLine("D. 4'ere");
                }
                if (sums[4] >= 1)
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[4])
                        Console.WriteLine("E. 5'ere");
                }
                if (sums[5] >= 1)
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[5])
                        Console.WriteLine("F. 6'ere");
                }
                if ((sums[0] >= 2) || (sums[1] >= 2) || (sums[2] >= 2) || (sums[3] >= 2) || (sums[4] >= 2) || (sums[5] >= 2))
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[6])
                        Console.WriteLine("G. Et par");
                }
                if ((sums[0] >= 2 && (sums[1] >= 2 || sums[2] >= 2 || sums[3] >= 2 || sums[4] >= 2 || sums[5] >= 2)) ||       // er der mere end to 1'ere && mere end 2 af en anden værdi?
                        (sums[1] >= 2 && (sums[2] >= 2 || sums[3] >= 2 || sums[4] >= 2 || sums[5] >= 2)) ||                   // er der mere end to 2'ere && mere end 2 af en anden værdi?
                        (sums[2] >= 2 && (sums[3] >= 2 || sums[4] >= 2 || sums[5] >= 2)) ||                                   // osv...
                        (sums[3] >= 2 && (sums[4] >= 2 || sums[5] >= 2)) ||
                        (sums[4] >= 2 && sums[5] >= 2))
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[7])
                        Console.WriteLine("H. To par");
                }
                if ((sums[0] >= 3) || (sums[1] >= 3) || (sums[2] >= 3) || (sums[3] >= 3) || (sums[4] >= 3) || (sums[5] >= 3))
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[8])
                        Console.WriteLine("I. Tre ens");
                }
                if ((sums[0] >= 4) || (sums[1] >= 4) || (sums[2] >= 4) || (sums[3] >= 4) || (sums[4] >= 4) || (sums[5] >= 4))
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[9])
                        Console.WriteLine("J. Fire ens");
                }
                if ((sums[0] == 1) && (sums[1] == 1) && (sums[2] == 1) && (sums[3] == 1) && (sums[4] == 1))                 // tæller om der er en af hver værdi, fordi så er der en straight
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[10])
                        Console.WriteLine("K. Lille Straight");
                }
                if ((sums[1] == 1) && (sums[2] == 1) && (sums[3] == 1) && (sums[4] == 1) && (sums[5] == 1))
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[11])
                        Console.WriteLine("L. Store Straight");
                }
                if ((sums[0] == 3) || (sums[1] == 3) || (sums[2] == 3) || (sums[3] == 3) || (sums[4] == 3) || (sums[5] == 3))
                {
                    if ((sums[0] == 2) || (sums[1] == 2) || (sums[2] == 2) || (sums[3] == 2) || (sums[4] == 2) || (sums[5] == 2))
                    {
                        if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[12])
                            Console.WriteLine("M. Fuldt hus");                                                              // er der mere end to 1'ere && mere end 3 (!) af en anden værdi? osv.
                    }
                }
                if ((sums[0] == 5) || (sums[1] == 5) || (sums[2] == 5) || (sums[3] == 5) || (sums[4] == 5) || (sums[5] == 5))
                {
                    if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[13])
                        Console.WriteLine("N. Yatzy");
                }
                if (!spillere[nuværendeSpiller].TjekOmBrugtFoer[14])
                    Console.WriteLine("O. Chancen");

                Console.WriteLine("Dine terninger er: " + terninger[0] + ", " + terninger[1] + ", " + terninger[2] + ", " + terninger[3] + ", " + terninger[4]);

                choice = Console.ReadLine().ToLower();

                switch (choice)
                {
                    case "a":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[0] = true;
                        score = sums[0] * 1;
                        spillere[nuværendeSpiller].Scoring[0] = score;
                        break;
                    case "b":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[1] = true;
                        score = sums[1] * 2;
                        spillere[nuværendeSpiller].Scoring[1] = score;
                        break;
                    case "c":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[2] = true;
                        score = sums[2] * 3;
                        spillere[nuværendeSpiller].Scoring[2] = score;
                        break;
                    case "d":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[3] = true;
                        score = sums[3] * 4;
                        spillere[nuværendeSpiller].Scoring[3] = score;
                        break;
                    case "e":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[4] = true;
                        score = sums[4] * 5;
                        spillere[nuværendeSpiller].Scoring[4] = score;
                        break;
                    case "f":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[5] = true;
                        score = sums[5] * 6;
                        spillere[nuværendeSpiller].Scoring[5] = score;
                        break;
                    case "g":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[6] = true;
                        for (int i = 5; i >= 0; i--)
                        {
                            if (sums[i] == 2)
                                score = 2 * (i + 1);
                        }
                        spillere[nuværendeSpiller].Scoring[6] = score;
                        break;
                    case "h":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[7] = true;
                        for (int i = 0; i < 6; i++)
                        {
                            if (sums[i] == 2)
                            {
                                for (int j = i + 1; j < 6; j++)
                                    if (sums[j] == 2) score = (2 * (i + 1)) + (2 * (j + 1));
                            }
                        }
                        spillere[nuværendeSpiller].Scoring[7] = score;
                        break;
                    case "i":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[8] = true;
                        if (sums[0] == 3) score = 3;
                        else if (sums[1] == 3) score = 6;
                        else if (sums[2] == 3) score = 9;
                        else if (sums[3] == 3) score = 12;
                        else if (sums[4] == 3) score = 15;
                        else if (sums[5] == 3) score = 18;
                        spillere[nuværendeSpiller].Scoring[8] = score;
                        break;
                    case "j":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[9] = true;
                        if (sums[0] == 4) score = 4;
                        else if (sums[1] == 4) score = 8;
                        else if (sums[2] == 4) score = 12;
                        else if (sums[3] == 4) score = 16;
                        else if (sums[4] == 4) score = 20;
                        else if (sums[5] == 4) score = 24;
                        spillere[nuværendeSpiller].Scoring[9] = score;
                        break;
                    case "k":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[10] = true;
                        score = 15;
                        spillere[nuværendeSpiller].Scoring[10] = score;
                        break;
                    case "l":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[11] = true;
                        score = 20;
                        spillere[nuværendeSpiller].Scoring[11] = score;
                        break;
                    case "m":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[12] = true;
                        for (int i = 0; i < 6; i++)
                        {
                            if (sums[i] == 3)
                            {
                                for (int j = 1; j < 6; j++)
                                    if (sums[j] == 2) score = (3 * (i + 1)) + (2 * (j + 1));
                            }
                        }
                        spillere[nuværendeSpiller].Scoring[12] = score;
                        break;
                    case "n":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[13] = true;
                        score = 50;
                        spillere[nuværendeSpiller].Scoring[13] = score;
                        break;
                    case "o":
                        spillere[nuværendeSpiller].TjekOmBrugtFoer[14] = true;
                        score = (sums[0] * 1) + (sums[1] * 2) + (sums[2] * 3) + (sums[3] * 4) + (sums[4] * 5) + (sums[5] * 6);
                        spillere[nuværendeSpiller].Scoring[14] = score;
                        break;
                    default:
                        Console.WriteLine("***Du har tastet noget forkert! Prøv igen.***");
                        vælgScoring();
                        break;
                }
                spillere[nuværendeSpiller].UdregnTotal();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Noget gik galt. Fejl: {0}", ex);
            }
        }

        do
        {
            Console.Clear();

            Console.WriteLine("\nRunde {0}\nDet er {1}s tur. Tryk <enter> for at rulle terningerne…", count, spillere[nuværendeSpiller].navn);
            Console.ReadLine();

            rulTerninger();
            visScoreboard();
            printTerninger();
            Console.Write("\nVil du kaste nogen terninger igen? Du har {0} kast tilbage. (Ja/Nej) : ", terningeKast);
            string kast = Console.ReadLine().ToLower();

            do
            {
                if (kast == "ja")
                {
                    terningerDerKastesIgen.Clear();                                                         // rydder listen, så værdierne på terninger der skal rulles igen ikke akkumulerer ved omkast

                    Console.Write("\nHvilke terninger vil du kaste igen? (Skriv f.eks. \"125\" for terning 1, 2 og 5) : ");
                    string vælgTerningerEllerKast = Console.ReadLine();

                    if (int.TryParse(vælgTerningerEllerKast, out int intValue))                             // TEST: er det tal, som brugerne har skrevet? (ikke nødvendigvis ét tal, men også flere, f.eks. '125') -- bruger skal kunne skrive flere værdier på samme tid, men at parse hvert tal hver for sig er en udfordring, da en int ikke kan parses --- man kan ikke indeksere ind i en int ligesom man kan i en string
                    {                                                                                       // TryParse tester om en string kun indeholder tal, og derfor ved vi, om det er tal --- jeg kunne ikke komme på en anden måde at teste en string for at være tal
                        foreach (char i in vælgTerningerEllerKast)                                          // gemmer først numrene på alle terninger, der skal kastes igen, inden de kastes, ved at tilføje dem til listen
                        {
                            int digit = int.Parse(i.ToString());                                            // omdanner 'i'-variablen fra char til string (foreach loopet kræver char-typen for at parse stringen "vælgTerningerEllerKast"), og så fra string til int, så værdien kan bruges til indexing

                            if (digit < 6)                                                                  // TJEK: har bruger valgt en terning, der ikke eksisterer? (terning 5 <)
                            {
                                terningerDerKastesIgen.Add(digit);                                          // gemmer nummeret på terningerne, der skal kastes igen, i listen "terningerDerKastesIgen"
                            }
                        }
                        kast = "kast";
                    }
                    else
                    {
                        Console.Write("Du har indtastet noget forkert. Tryk <enter> for at prøve igen.");
                        Console.ReadLine();
                    }
                }
                else if (kast == "kast" && terningeKast != 0)
                {
                    terningeKast--;                                                                         // spilleren bruger et kast
                    Console.Clear();
                    Console.Write("\nDe valgte terninger rulles igen! ... \n");

                    foreach (int i in terningerDerKastesIgen)                                               // bruger tallene fra listen som index til arrayet for at angive terningerne, som spilleren vil rulle igen ...
                    {
                        terninger[i - 1] = r.Next(1, 7);                                                    // ... og de terninger får en ny random værdi (det er [i - 1] så det passer med zero-index i arrayet terninger, og 7, ikke 6, fordi anden parameter i Next() ikke tæller med i mulige random værdier)
                    }

                    visScoreboard();
                    printTerninger();

                    if (terningeKast == 0)                                                                  // TJEK: Var det spillerens sidste kast? fordi så skal de sendes til scoreboardet
                    {
                        Console.WriteLine("\nDet var sidste kast, så vi går til scoreboardet!");
                        vælgScoring();
                        Console.WriteLine("Din score er {0}", score);
                        break;
                    }
                    Console.Write("\nVil du kaste igen? Du har {0} kast tilbage. (Ja/Nej) : ", terningeKast);
                    kast = Console.ReadLine().ToLower();
                }
                else if (kast == "nej" || terningeKast == 0)
                {
                    vælgScoring();
                    Console.WriteLine("Din score er {0}", score);
                    break;
                }
                else
                {
                    Console.Write("Du har indtastet noget forkert. Tryk <enter> for at prøve igen.");
                    Console.ReadLine();
                    kast = "ja";                                                                            // hvis kast er "ja" looper det tilbage til toppen
                }
            } while (kastIgen == true && terningeKast != 0);

            visScoreboard();

            if (count == 15 && nuværendeSpiller == antalSpillere - 1)
            {
                for (int i = 0; i < antalSpillere; i++)
                {
                    int spillerScore = spillere[i].UdregnTotal();

                    if (spillerScore > maksScore)                                                   // Hvis den aktuelle spiller har en højere score end den hidtil maksimale score, opdater vinderen og den maksimale score
                    {
                        maksScore = spillerScore;
                        vinder = spillere[i].navn;
                    }
                }
                Console.WriteLine("***Vinderen er: ***" + vinder);
            }


            terningeKast = 2;

            if (nuværendeSpiller == antalSpillere - 1)
            {
                nuværendeSpiller = 0;
                count++;
            }
            else
                nuværendeSpiller++;

        } while (Console.ReadLine() != "q");
    }
}


